class Vehicle(val name: String, val wheels: Int) {
    fun startEngine() {
        println("Engine started")
    }
}

