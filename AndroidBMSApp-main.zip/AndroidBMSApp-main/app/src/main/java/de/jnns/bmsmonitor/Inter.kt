interface Clickable {
    fun onClick()
}