class Motorcycle(name: String, wheels: Int, val type: String) : Vehicle(name, wheels) {
    fun popWheelie() {
        println("Popping wheelie")
    }
}

fun main() {
    val car = Car("Toyota", 4, "Corolla")
    val motorcycle = Motorcycle("Harley", 2, "Cruiser")

    car.startEngine()
    motorcycle.popWheelie()
}